#include <stdio.h>
main()
{
 int a;
 return 0;
}
